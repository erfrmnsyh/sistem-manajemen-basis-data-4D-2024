# Pemrograman Bergerak 4D 2024
Kumpulkan tugas dari modul 5 di folder ini, penamaan folder tugas praktikum dengan format NIM-NamaKamu, dan untuk nama tidak menggunakan spasi, namun diganti dengan huruf kapital di setiap nama

contoh: 200441100014-KevinMalikFajar

Jangan lupa untuk membuat ZIP project sebelum memindahkannya ke folder NIM-NamaKamu agar ukuran project tidak terlalu besar
Sebagai perbandingan, ukuran project sebelum di ZIP adalah ±50 mb dan setelah di ZIP menjadi 155 kb (bisa lebih tergantung besarnya project)
Cara ZIP yaitu klik File -> Export -> Export to ZIP FIle...