package com.example.modultiga.data

data class HotelData(
    val nama : String,
    val jumlah_pengunjung : Int,
    val rating : Double,
    val deskripsi : String,
    val gambar : Int
)
